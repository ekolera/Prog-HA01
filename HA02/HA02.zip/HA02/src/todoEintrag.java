import java.util.Date;

import javax.faces.bean.ManagedBean;

@ManagedBean

public class todoEintrag {

	private Integer id;
	private String beschreibung;
	private String deadline;
	private String prozent;

	public String getProzent() {
		return prozent;
	}

	public void setProzent(String prozent) {
		this.prozent = prozent;
	}

	public String getDeadline() {
		return deadline;
	}

	public void setDeadline(String deadline) {
		this.deadline = deadline;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

}
