
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@ManagedBean

public class todoEintragBean {
	Connection conn = null;
	static ResultSet resultSet = null;
	static Statement statement = null;
	public static Integer idGenerator = 1;
	private String todoeditier;
	private static String beschreibung;
	private static String deadline;
	private static String prozent;
	private static Integer id;

	public String getTodoeditier(todoEintrag todo) {
		beschreibung = todo.getBeschreibung();
		deadline = todo.getDeadline();
		prozent = todo.getProzent();
		id = todo.getId();

		return todoeditier;
	}

	public List<todoEintrag> getTodoliste() throws ClassNotFoundException, SQLException, ParseException {

		try {
			// db parameters
			String url = "jdbc:sqlite:C:/Users/Ecem/Desktop/SS2017/Prog Praktikum/Datenbank.db";

			// create a connection to the database
			conn = DriverManager.getConnection(url);

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		List<todoEintrag> todoliste = new ArrayList<todoEintrag>();
		statement = conn.createStatement();
		resultSet = statement.executeQuery("SELECT * FROM TODOLISTE");

		while (resultSet.next()) {

			todoEintrag todo = new todoEintrag();
			todo.setId(resultSet.getInt("id"));
			todo.setBeschreibung(resultSet.getString("beschreibung"));
			todo.setDeadline(resultSet.getString("deadline"));
			todo.setProzent(resultSet.getString("prozent"));

			todoliste.add(todo);

		}

		return todoliste;

	}

	public static void delete(todoEintrag eintrag) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			String url = "jdbc:sqlite:C:/Users/Ecem/Desktop/SS2017/Prog Praktikum/Datenbank.db";
			con = DriverManager.getConnection(url);
			String sql = "DELETE FROM TODOLISTE WHERE ID =" + eintrag.getId();
			ps = con.prepareStatement(sql);
			ps.executeUpdate();

		} catch (SQLException e) {
			System.out.println(" SQLException :(");
			e.printStackTrace();
		}
	}

	public static void update(Integer id) {

		Connection con = null;
		PreparedStatement ps = null;

		try {
			String url = "jdbc:sqlite:C:/Users/Ecem/Desktop/SS2017/Prog Praktikum/Datenbank.db";
			con = DriverManager.getConnection(url);
			String sql = "UPDATE TODOLISTE SET beschreibung = ?, id = ?, deadline = ?, prozent = ? WHERE id=" + id;
			ps = con.prepareStatement(sql);

			// set the preparedstatement parameters
			ps.setString(1, beschreibung);
			ps.setInt(2, id);
			ps.setString(3, deadline);
			ps.setString(4, prozent);

			ps.executeUpdate();

		} catch (SQLException e) {
			System.out.println(" SQLException :(");
			e.printStackTrace();
		}
	}

	public static void insert(todoEintrag eintrag) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			String url = "jdbc:sqlite:C:/Users/Ecem/Desktop/SS2017/Prog Praktikum/Datenbank.db";
			con = DriverManager.getConnection(url);

			String beschreibung = eintrag.getBeschreibung();
			// Integer id = idGenerator++;
			String deadline = eintrag.getDeadline();
			String prozent = eintrag.getProzent();

			Random zufallszahl = new Random();
			Integer id = zufallszahl.nextInt();

			String sql = "INSERT INTO TODOLISTE VALUES (?, ?, ?, ?)";

			ps = con.prepareStatement(sql);
			ps.setString(1, beschreibung);
			ps.setInt(2, id);
			ps.setString(3, deadline);
			ps.setString(4, prozent);

			ps.executeUpdate();

		} catch (SQLException e) {
			System.out.println(" SQLException :(");
			e.printStackTrace();
		}
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	public String getDeadline() {
		return deadline;
	}

	public void setDeadline(String deadline) {
		this.deadline = deadline;
	}

	public String getProzent() {
		return prozent;
	}

	public void setProzent(String prozent) {
		this.prozent = prozent;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setTodoeditier(String todoeditier) {
		this.todoeditier = todoeditier;
	}
}
